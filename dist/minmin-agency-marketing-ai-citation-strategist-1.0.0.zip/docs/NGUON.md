# Nguồn của agent `agency-marketing-ai-citation-strategist`

Một agent lẻ của gói `minmin.agency-agents`, lấy từ [msitarzewski/agency-agents/marketing/marketing-ai-citation-strategist.md](https://github.com/msitarzewski/agency-agents/blob/main/marketing/marketing-ai-citation-strategist.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho MinMin (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, MinMin báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
