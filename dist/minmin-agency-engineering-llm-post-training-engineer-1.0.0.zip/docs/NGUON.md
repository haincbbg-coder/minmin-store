# Nguồn của agent `agency-engineering-llm-post-training-engineer`

Một agent lẻ của gói `minmin.agency-agents`, lấy từ [msitarzewski/agency-agents/engineering/engineering-llm-post-training-engineer.md](https://github.com/msitarzewski/agency-agents/blob/main/engineering/engineering-llm-post-training-engineer.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho MinMin (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, MinMin báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
