# Gói `minmin.gate` - MinMin Gate

Cổng cho **ChatGPT, Claude và AI khác** làm việc cùng MinMin. Bạn chat trên chatgpt.com hay claude.ai bằng gói của mình, và AI đó gọi sang MinMin khi cần: xem số liệu, đọc brain, tạo nhắc lịch, gửi Zalo...

Điểm mới từ bản 2.0.0: AI đó **đọc được hội thoại của MinMin và nhắn thẳng vào khung chat** như bạn gõ. Ví dụ:

> "Đọc hội thoại Viết Web trên MinMin rồi tư vấn anh nên làm gì tiếp."

AI đọc, tư vấn cho bạn. Bạn đồng ý ngay trên ChatGPT (hay Claude), nó nhắn vào đúng hội thoại "Viết Web" để MinMin làm tiếp. Trên MinMin bạn thấy tin đó với nhãn **từ ChatGPT**, thấy MinMin trả lời từng chữ, bấm **Dừng** được, và MinMin nhớ lại cho lần sau.

> Tiền thân là gói **MinMin trong ChatGPT** (`minmin.minmin-trong-chatgpt`). Máy đang cài gói cũ thấy MinMin Gate như một bản cập nhật: token, mức quyền và địa chỉ đã dán vào ChatGPT được giữ nguyên, không phải kết nối lại.

---

## Trong gói có gì

| Loại | Slug | Việc |
|---|---|---|
| Plugin | `minmin-gate` | Cửa OAuth và địa chỉ MCP cho ChatGPT, Claude, cùng một trang cài đặt riêng |

AI bên ngoài dùng đúng bộ công cụ MinMin đã có (kết nối MCP, brain, nhắc lịch, Kanban, plugin), cộng bốn công cụ chỉ có ở cổng này:

| Công cụ | Việc | Mức quyền |
|---|---|---|
| `minmin_chat_find` | Tìm hội thoại theo tên hoặc nội dung | Mọi mức |
| `minmin_chat_read` | Đọc các tin cuối của một hội thoại | Mọi mức |
| `minmin_chat_send` | Nhắn vào hội thoại để MinMin làm, rồi chờ câu trả lời | Chỉ Toàn quyền |
| `minmin_chat_result` | Đọc câu trả lời khi MinMin làm lâu | Mọi mức |

## Cần có gì

- **MinMin OS 0.440.0 trở lên.** Bản cũ hơn thì gói bị tắt kèm lý do ngay lúc cài.
- **Gói trả phí** của ChatGPT (Plus, Pro, Business, Enterprise, Edu) hoặc của Claude (Pro, Max, Team, Enterprise).
- **Máy tính** cho bước cài đặt lần đầu.
- **MinMin có địa chỉ https.** ChatGPT và Claude không nhận địa chỉ kiểu `http://12.34.56.78:7777`. Gắn tên miền riêng trước (Cài đặt, mục Giọng nói, thương hiệu và truy cập).
- **MinMin đã đặt mật khẩu quản trị.** Bước cho phép dựa vào đăng nhập dashboard. Chưa có mật khẩu thì cổng này đóng.

---

## Bước 1: Cài gói và lấy địa chỉ

1. Mở **MinMin Store**, tìm **MinMin Gate**, bấm cài và đồng ý chạy mã.
2. Vào trang **Plugin**, tìm thẻ **MinMin Gate**, bấm **Mở trang**.
3. Bấm **Chép** để chép địa chỉ. Nó có dạng `https://ten-mien-cua-ban/ext/minmin-gate/mcp`.

## Bước 2a: Nối với ChatGPT

1. Gói **Business**: quản trị viên vào **Workspace settings, Permissions & roles, Connected data**, bật **Create custom MCP connectors**.
2. Trên chatgpt.com (máy tính): **Settings, Apps & Connectors, Advanced settings**, bật **Developer mode**.
3. Vẫn ở **Apps & Connectors**, bấm **Create**, điền:

| Ô | Điền gì |
|---|---|
| Name | `MinMin` |
| MCP Server URL | địa chỉ đã chép ở bước 1 |
| Authentication | **OAuth** |

4. Tích ô xác nhận tin tưởng connector, bấm **Create**.

## Bước 2b: Nối với Claude

1. Trên claude.ai (hoặc app Claude Desktop): **Settings, Connectors**, bấm **Add custom connector**.
2. Đặt tên `MinMin`, dán địa chỉ đã chép ở bước 1, bấm **Add**.
3. Bấm **Connect** trên connector vừa tạo.

Gói Team hay Enterprise thì chủ sở hữu tổ chức thêm connector trước ở phần quản trị, thành viên chỉ cần bấm Connect.

> Tên các mục có thể hơi khác theo phiên bản ChatGPT hay Claude. Tìm chữ "Connectors" trong phần Settings.

## Bước 3: Cho phép

ChatGPT hoặc Claude mở một trang của MinMin.

- Trình duyệt chưa đăng nhập MinMin thì trang hiện ô đăng nhập ngay tại chỗ (có cả ô mã 2 lớp nếu bạn đã bật).
- Trang tiếp theo nói rõ AI đó được làm gì và đang ở mức quyền nào. Bấm **Cho phép**.

## Bước 4: Dùng

Bật connector MinMin trong khung chat (ChatGPT: dấu **+**, chọn **Developer mode**, bật **MinMin**; Claude: nút công cụ, bật **MinMin**). Thử:

- "Trên MinMin có những hội thoại nào gần đây?"
- "Đọc hội thoại Viết Web trên MinMin rồi tư vấn anh nên làm gì tiếp."
- "Ok, bảo MinMin làm theo phương án 2."

MinMin làm lâu thì AI kia báo kết quả sẽ hiện trên khung chat của MinMin, và bạn nhắn nó **"xem tiếp"** khi muốn nó đọc lại.

---

## Mức quyền

Chọn trên trang của gói (trang Plugin, nút **Mở trang**). Đổi xong có hiệu lực ngay, không cần kết nối lại.

| Mức | AI bên ngoài được làm gì |
|---|---|
| **Toàn quyền** (mặc định) | Đọc dữ liệu, nhắn vào khung chat để MinMin làm, và làm việc thật: gửi tin, tạo đơn, đăng bài |
| **Tự làm có giới hạn** | Đọc dữ liệu, đọc hội thoại và viết nháp. Không nhắn vào khung chat, không làm việc ra bên ngoài |
| **Chỉ đọc và gợi ý** | Chỉ đọc, kể cả đọc hội thoại. Không ghi file, không nhắn vào khung chat |

MinMin tự chặn ở phía mình theo mức đã chọn. AI bên ngoài không tự nâng quyền được.

## Ngắt kết nối

- **Tạm dừng:** tắt gói **MinMin Gate** ở MinMin Store. Kết nối cũ giữ nguyên, bật lại là dùng tiếp.
- **Ngắt hẳn:** bấm **Ngắt mọi kết nối** trên trang của gói. Muốn dùng lại thì nối lại từ bước 2.
- **Gỡ gói:** gỡ ở MinMin Store. Mọi đường của gói biến mất cùng lúc.

---

## Điều cần biết trước

- **AI bên ngoài không tự thức dậy.** Nó chỉ đọc được câu trả lời của MinMin trong lúc nó đang trả lời bạn. Việc dài thì kết quả luôn nằm trên khung chat của MinMin, và bạn nhắn AI kia "xem tiếp" khi cần.
- **Tin nhắn vào khung chat tốn hạn mức bộ não của MinMin.** Lượt đó chạy bằng model bạn chọn cho MinMin (Claude Code, Codex...), như khi bạn tự gõ. Phần tư vấn bên ChatGPT hay Claude thì tốn hạn mức gói bên đó.
- **Chỉ nhắn được vào hội thoại của bạn** (khung Trò chuyện, chat với Cộng sự). Hội thoại của khách và nhóm chat thì AI bên ngoài không đọc, không nhắn được.
- **Công cụ ngoài khung chat làm việc trên brain đang mở gần nhất.** Kết quả mỗi công cụ có ghi rõ đang ở brain nào. Tin nhắn vào khung chat thì chạy trên brain của chính hội thoại đó.

## Khi không chạy

| Bạn thấy | Nguyên nhân | Làm gì |
|---|---|---|
| Không có mục Developer mode (ChatGPT) | Gói miễn phí, hoặc đang ở app điện thoại | Dùng gói trả phí, mở chatgpt.com trên máy tính |
| Không có nút Add custom connector (Claude) | Gói miễn phí, hoặc tổ chức chưa cho phép | Dùng gói trả phí, hỏi chủ sở hữu tổ chức |
| Báo không kết nối được server | Địa chỉ không phải https, gói đang tắt, hoặc MinMin chưa có mật khẩu | Xem lại "Cần có gì" và bước 1 |
| AI báo cần mức Toàn quyền khi nhắn vào khung chat | Gói đang ở mức thấp hơn | Nâng mức quyền trên trang của gói |
| Trang MinMin báo "Yêu cầu này đã quá hạn" | Để trang Cho phép mở quá 10 phút | Kết nối lại từ ChatGPT hoặc Claude |
| Đang dùng tốt bỗng bắt kết nối lại | 30 ngày không dùng, hoặc đã bấm Ngắt mọi kết nối | Kết nối lại |

## An toàn

- Token chỉ lưu dạng băm trong thư mục dữ liệu riêng của gói, không nằm trong brain.
- Cổng chỉ trả mã về đúng máy của OpenAI (`chatgpt.com`, `*.openai.com`), của Anthropic (`claude.ai`, `claude.com`), hoặc chính máy của bạn (`localhost`, cho Claude Code và Claude Desktop). Kẻ gian tự đăng ký một kết nối trỏ về máy mình sẽ không nhận được mã.
- Token của gói này tách hẳn khỏi token Claude Code và Codex dùng. Ngắt bên này không ảnh hưởng bên kia.
- Refresh token xoay vòng: một token cũ bị dùng lại là MinMin thu hồi cả chuỗi và bắt cho phép lại.
