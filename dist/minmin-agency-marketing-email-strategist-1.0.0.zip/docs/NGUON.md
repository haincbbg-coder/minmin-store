# Nguồn của agent `agency-marketing-email-strategist`

Một agent lẻ của gói `minmin.agency-agents`, lấy từ [msitarzewski/agency-agents/marketing/marketing-email-strategist.md](https://github.com/msitarzewski/agency-agents/blob/main/marketing/marketing-email-strategist.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho MinMin (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, MinMin báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
