# Nguồn của gói theo repo gốc `browser-use/video-use`

Skill trong gói này chép **nguyên văn** từ [browser-use/video-use](https://github.com/browser-use/video-use), nhánh `main`:
không dịch, không rút gọn, không sửa frontmatter.

Mỗi ngày kho so lại với repo gốc (`tools/theo-goc.py`). Repo gốc đổi thì gói lên một bản
vá, MinMin báo trong chuông và bạn bấm Cập nhật. Skill bạn đã tự sửa thì MinMin giữ lại,
không ghi đè. Commit gốc của bản đang phát hành nằm ở trường `upstream.commit` trong
`index.json`.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*` nếu repo có.

| Skill | Thư mục gốc |
|---|---|
| `video-use` | `.` |
| `manim-video` | `skills/manim-video` |
