# Nguồn của agent `agency-gis-geoai-ml-engineer`

Một agent lẻ của gói `minmin.agency-agents`, lấy từ [msitarzewski/agency-agents/gis/gis-geoai-ml-engineer.md](https://github.com/msitarzewski/agency-agents/blob/main/gis/gis-geoai-ml-engineer.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho MinMin (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, MinMin báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
